<div align="center">

<img src="docs/intro.gif" alt="Un notebook en 3D: la cámara se acerca a la pantalla y entra en la web de CorePulse" width="720">

# CorePulse Web

**La web de CorePulse: precios, descargas, novedades y cuentas de usuario.**

[corepulse.cl](https://corepulse.cl) · [Funciones](https://corepulse.cl/funciones) · [Precios](https://corepulse.cl/precios) · [Descargar](https://corepulse.cl/descargar)

![Next.js 16](https://img.shields.io/badge/Next.js-16-000?logo=nextdotjs)
![React 19](https://img.shields.io/badge/React-19-149eca?logo=react&logoColor=white)
![Tailwind 4](https://img.shields.io/badge/Tailwind-4-38bdf8?logo=tailwindcss&logoColor=white)
![Supabase](https://img.shields.io/badge/Supabase-DB%20%C2%B7%20Auth%20%C2%B7%20Storage-3ecf8e?logo=supabase&logoColor=white)
![Cloudflare Workers](https://img.shields.io/badge/Cloudflare-Workers-f38020?logo=cloudflare&logoColor=white)

</div>

**Todo el contenido sale de Supabase**: textos, precios, planes, funciones, novedades, preguntas, legales e imágenes. En el código solo quedan etiquetas de interfaz (botones, menús). ¿Quieres cambiar un precio? Se edita una fila en Supabase y no hace falta tocar el código.

**Stack:** Next.js 16 (React 19) · Tailwind CSS 4 · Motion + Lenis (animaciones) · Supabase (base de datos, Auth y Storage) · Cloudflare Workers con OpenNext (hosting) en `https://corepulse.cl`.

## ⚡ CorePulse en 30 segundos

```mermaid
flowchart LR
    TU["🧑‍💻 Tú<br/>Table Editor"] -->|editas una fila| DB[("Supabase<br/>tablas + Storage")]
    DB -->|lectura| CF["☁️ Cloudflare Worker<br/>Next.js + OpenNext"]
    CF <-->|"caché 60 s<br/>respaldo 7 días"| CACHE[("Caché de<br/>Cloudflare")]
    CF -->|página| WEB["🌐 corepulse.cl"]
    APP["🖥️ App de escritorio"] -->|"/api/app/*"| CF
    CF -->|"cuentas y planes"| DB
```

Si Supabase se cae, la web sigue funcionando con la última copia guardada.

### Así inicia sesión la app de escritorio (sin pedir la contraseña)

```mermaid
sequenceDiagram
    autonumber
    participant App as 🖥️ App
    participant Nav as 🌐 Navegador
    participant Web as ☁️ corepulse.cl
    App->>App: genera verificador secreto<br/>y escucha en 127.0.0.1
    App->>Nav: abre /app/conectar?reto=SHA-256(verificador)
    Nav->>Web: el usuario inicia sesión y pulsa «Autorizar este equipo»
    Web-->>App: redirige a 127.0.0.1/callback con un código (2 min)
    App->>Web: POST /api/app/token (código + verificador)
    Web-->>App: token de equipo 🎟️
    App->>Web: GET /api/app/yo
    Web-->>App: nombre, email y plan
```

## 🚀 Puesta en marcha

<details>
<summary><b>1. Supabase</b> · base de datos, cuentas e imágenes</summary>

1. **SQL Editor** → ejecuta en orden los archivos de `supabase/migrations/`:
   1. `…_contenido.sql`: tablas del contenido, seguridad (RLS) y bucket `capturas`.
   2. `…_datos_iniciales.sql`: el contenido actual de la web (se puede repetir sin duplicar).
   3. `…_cuentas.sql`: perfiles de usuario con su plan.
   4. `…_precios_clp_y_limite_free.sql`: precios en pesos chilenos y plan Free con 2 usos por función.
   5. `…_app_escritorio.sql`: inicio de sesión de la app de escritorio.
   6. `…_caducidad_tokens_app.sql`: los tokens de la app caducan (30 días sin uso o 180 días desde que se conectó el equipo).
   7. `…_administradores.sql`: cuentas admin que pueden cambiar los precios desde `/cuenta/admin`.
   8. `…_gestionar_admins.sql`: los admins dan o quitan admin a otras cuentas por email.
   9. `…_capturas_windows.sql`: usa las capturas sacadas en Windows (con todas las métricas visibles).
   10. `…_novedades_github.sql`: vacía Novedades y la prepara para recibir las versiones desde GitHub.
2. **Authentication → URL Configuration:**
   - *Site URL:* `https://corepulse.cl`.
   - *Redirect URLs:* añade `https://corepulse.cl/auth/callback` y `http://localhost:3000/auth/callback`.
3. **Authentication → Sign In / Providers → Email:** deja activado *Confirm email*.
4. Copia `.env.example` como `.env.local` y rellena las claves (**Project Settings → API Keys**).
5. Sube las imágenes al Storage:
   ```bash
   npm run subir-capturas
   ```

</details>

<details>
<summary><b>2. Cloudflare Workers</b> · hosting en corepulse.cl</summary>

1. **Workers & Pages → Create → Import a repository** → elige este repositorio (Workers Builds). Usa la configuración por defecto: `npm run build` compila con OpenNext y `wrangler.jsonc` define el Worker y los dominios `corepulse.cl` y `www.corepulse.cl`.
2. Las variables públicas de compilación (`NEXT_PUBLIC_SUPABASE_URL`, `NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY`, `NEXT_PUBLIC_SITE_URL`) están en `.env.production`. Si prefieres definirlas en Cloudflare, ponlas en **Settings → Build → Variables** y en **Settings → Variables and Secrets**.
3. Cada `git push` a la rama configurada en Workers Builds vuelve a publicar. A mano: `npm run deploy`.

> [!WARNING]
> Las variables `NEXT_PUBLIC_*` se incrustan al compilar: si las cambias, lanza una nueva compilación.
> **Nunca** pongas `SUPABASE_SECRET_KEY` en Cloudflare: solo se usa en tu equipo para subir imágenes.

</details>

## ✏️ Editar el contenido

Todo se edita en **Supabase → Table Editor**. La web se actualiza sola en un máximo de **60 segundos**: las lecturas de Supabase se guardan un minuto en la caché de Cloudflare (`src/lib/supabase/cache.ts`). Si Supabase falla, la web sigue mostrando la última copia guardada (hasta 7 días). En local (`npm run dev`) no hay caché y los cambios se ven al instante.

<details>
<summary><b>¿Qué tabla cambia qué?</b></summary>

| Tabla | Qué controla |
|---|---|
| `ajustes` | Textos por página en JSON: `sitio` (nombre, versión, enlace de descarga, email de soporte), `inicio`, `funciones`, `precios`, `descargar`, `novedades` |
| `planes` | Planes Free/Pro: nombre, precios mensual y anual, botón. `moneda` con código ISO (`CLP`, `USD`…) usa el formato oficial (`$4.990`) |
| `plan_caracteristicas` | Filas de la comparativa (`true`, `false` o un texto como `"2 usos"`) |
| `preguntas` | Preguntas frecuentes (sección `precios`) |
| `funciones` | Módulos de la página Funciones; `en_portada` los muestra en la sección fija del inicio |
| `destacados` | Tarjetas del inicio (icono: `gamepad`, `thermo`, `wrench`, `bolt`, `lock`) |
| `cifras` | Contadores animados del inicio |
| `temas` | Galería horizontal de temas |
| `versiones` | Página Novedades. Se llena sola desde los Releases de GitHub (ver [`docs/github/README.md`](docs/github/README.md)); también se pueden añadir filas a mano |
| `documentos_legales` | Términos, privacidad y reembolsos (crear una fila nueva publica `/legal/<slug>`) |
| `perfiles` | Usuarios registrados y su plan (`free`/`pro`) |

Las imágenes van en **Storage → capturas**; en las tablas se escribe solo el nombre del archivo (`summary.jpg`).

</details>

<details>
<summary><b>📸 Cambiar capturas</b></summary>

1. Saca las capturas nuevas de la app (mejor en Windows, con la ventana en proporción ~16:9.5, como 1800×1068) y ponlas en `contenido/capturas-nuevas/` con el nombre de la que reemplazan, en cualquier formato: `summary.png`, `health.png`, `tweaks.png`, `cleanup.png`, `themes.png`, `tema_aurora.png`, `tema_violet.png`, `tema_ember.png`, `tema_sakura.png`, `tema_cyber.png`. Puedes cambiar solo algunas.
2. `npm run actualizar-capturas -- --prueba` las deja preparadas en `contenido/capturas/` para revisarlas (1800×1068, WebP).
3. `npm run actualizar-capturas` las prepara, las sube a Supabase y cambia las tablas (`funciones`, `temas`, `ajustes`). Necesita `SUPABASE_SECRET_KEY` en `.env.local`.
4. Haz commit de `contenido/capturas/` para que el repositorio quede igual que la web.

Cada subida usa un nombre nuevo (`summary-20261015-1830.webp`): las imágenes llevan 7 días de caché y con el mismo nombre los navegadores seguirían mostrando la vieja. La captura usada como vista previa en redes (`ajustes.sitio.imagenSocial`) se genera además en JPEG de 1200×630.

</details>

## 👤 Cuentas

- `/registro`, `/login`, `/recuperar`, `/cuenta`, `/cuenta/contrasena`, `/logout` (las mismas rutas que abre el menú de la app).
- Contraseña mínima de 8 caracteres y confirmación por email.
- El **plan** solo lo cambia el servidor o tú desde el panel: la seguridad de la base de datos impide que un usuario se lo cambie.
- **Admin:** en el SQL Editor, `update public.perfiles set es_admin = true where id = (select id from auth.users where email = 'tu@email.com');`. Hace falta solo para el primer admin: desde `/cuenta/admin` cualquier admin cambia los precios (solo los precios; el resto de la tabla `planes` se sigue editando en Supabase) y da o quita admin a otras cuentas por email. Nadie puede quitarse el admin a sí mismo.

<details>
<summary><b>🖥️ Inicio de sesión desde la app de escritorio, paso a paso</b></summary>

La app nunca pide la contraseña: abre `/app/conectar` en el navegador y la web la devuelve a la app.

1. La app genera un verificador secreto, abre `/app/conectar?puerto=…&estado=…&reto=…` (reto = SHA-256 del verificador) y escucha solo en `127.0.0.1`.
2. El usuario inicia sesión (si hace falta) y pulsa **Autorizar este equipo** → la web crea un código de un solo uso (2 min) y redirige a `http://127.0.0.1:<puerto>/callback`.
3. La app canjea código + verificador en `POST /api/app/token` y recibe un token de equipo.
4. Con ese token: `GET /api/app/yo` (nombre, email, plan) y `POST /api/app/salir` (cerrar sesión).
5. El token caduca tras **30 días sin usarse** o a los **180 días** de conectar el equipo. Entonces `GET /api/app/yo` responde `401` y la app debe volver al paso 1.
6. Límite por IP (Rate Limiting de Cloudflare, en `wrangler.jsonc`): 10 canjes por minuto en `/api/app/token` y 60 peticiones por minuto en `/api/app/yo` y `/api/app/salir`. Al pasarse, la API responde `429` con `Retry-After: 60`.

En la base solo hay huellas SHA-256 de códigos y tokens (tablas `codigos_app` y `sesiones_app`, migración `…_app_escritorio.sql`). Cada usuario ve y desconecta sus equipos en **Mi cuenta**.

</details>

## 🛠️ Comandos

<details>
<summary><b>Ver todos</b></summary>

```bash
npm run dev             # desarrollo en http://localhost:3000 (necesita .env.local)
npm run build           # compilación de producción (OpenNext para Cloudflare)
npm run preview         # compila y prueba en local con el entorno de Workers
npm run deploy          # compila y publica en Cloudflare
npm run lint
npm run subir-capturas  # sube contenido/capturas a Supabase Storage
npm run actualizar-capturas  # cambia capturas: prepara, sube y actualiza las tablas (ver «Cambiar capturas»)
```

</details>
