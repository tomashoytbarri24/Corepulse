# Novedades desde GitHub

Guía técnica para conectar el repositorio del programa con la página [`/novedades`](https://corepulse.cl/novedades).

Cuando publicas un **Release** en el repositorio del programa, una GitHub Action lo guarda en la tabla `versiones` y aparece en `/novedades` en menos de un minuto. Si editas o borras el Release, la web también se actualiza.

**Conectarlo (una sola vez):**

1. Ejecuta la migración `…_novedades_github.sql` en Supabase.
2. En Supabase, **Project Settings → API Keys → Secret keys → New secret key**, llámala `github-novedades`. Úsala solo para esto: si algún día se filtra, la borras sin afectar al resto.
3. En el repositorio **del programa**, **Settings → Secrets and variables → Actions → New repository secret**:
   - `SUPABASE_URL`: la URL del proyecto (`https://….supabase.co`).
   - `SUPABASE_NOVEDADES_KEY`: la clave del paso 2.
4. Copia [`novedades-web.yml`](novedades-web.yml) (en esta misma carpeta) a `.github/workflows/novedades-web.yml` del programa y haz commit.

**Cómo escribir el Release:**

| En GitHub | En la web |
|---|---|
| Etiqueta (tag), sin espacios, p. ej. `REBUILD-146` | La versión: los guiones se ven como espacios («REBUILD 146») |
| Nombre del Release | El título |
| Primer párrafo del texto | La explicación corta |
| Cada línea que empieza por `- ` | Un cambio de la lista |

```markdown
La limpieza de RAM ahora tarda la mitad y hay un tema nuevo.

- Limpieza de RAM en un clic desde la bandeja.
- Nuevo tema Ocean.
```

Los borradores y las *pre-release* no se publican. El enlace «Ver en GitHub» solo aparece si el repositorio del programa es público.

## Detalles técnicos

- Cada Release se guarda en la tabla `versiones` con su `github_id`. Al editar el Release se actualiza la misma fila (`on_conflict=github_id`) y al borrarlo se borra la fila.
- Columnas: `version` (tag, con `-` y `_` cambiados por espacios), `titulo` (nombre), `resumen` (texto que no es lista ni título, máx. 600 caracteres), `cambios` (líneas `- `, `* ` o `+ `), `enlace` (vacío si el repositorio es privado), `publicado` (fecha del Release), `origen = 'github'`.
- La web lee Supabase con la caché de 60 segundos, por eso tarda hasta un minuto en verse.
- La clave vive solo en los Secrets de GitHub, nunca en Cloudflare.
